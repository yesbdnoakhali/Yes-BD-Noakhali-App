// Sample Data for Activities
const activities = [
    {
        title: "Community Tree Planting",
        description: "Join us to plant trees in local parks and help make Noakhali greener.",
        image: "tree-planting.jpg", // Add the actual image path here
        pdf: "tree-planting-details.pdf" // Add the actual PDF path here
    },
    {
        title: "Beach Cleanup",
        description: "Help clean up the coastline, collect waste, and keep our beaches pristine.",
        image: "beach-cleanup.jpg", // Add the actual image path here
        pdf: "beach-cleanup-details.pdf" // Add the actual PDF path here
    }
];

// Function to Create Activity Cards
function createActivityCard(activity) {
    return `
        <div class="activity-card">
            <img src="${activity.image}" alt="${activity.title}" class="activity-image">
            <h3>${activity.title}</h3>
            <p>${activity.description}</p>
            <div class="activity-download">
                <a href="${activity.pdf}" class="download-link" target="_blank">Download Details (PDF)</a>
            </div>
        </div>
    `;
}

// Function to Handle Registration
function handleRegister(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username && password) {
        document.getElementById('registerSection').style.display = 'none';
        document.getElementById('activityList').style.display = 'block';
        renderData();
    } else {
        document.getElementById('registerMessage').textContent = "Please enter both username and password.";
    }
}

// Function to Render Data
function renderData() {
    const activityList = document.getElementById('activityList');
    activityList.innerHTML = activities.map(createActivityCard).join('');
}

// Initial Setup
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('registerForm').addEventListener('submit', handleRegister);
});
